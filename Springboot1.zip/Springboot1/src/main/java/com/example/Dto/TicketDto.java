package com.example.Dto;

import java.time.LocalDateTime;

import com.example.entities.Category;
import com.example.entities.Status;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


public class TicketDto {
	

	int id;
	

	String phonno;
	
	Category category;
	

	String issudetails;
	
	
	String resolutiondetails;
	
	
	Status status;
	
	
	LocalDateTime createdatetime;
	
	
	LocalDateTime resolutiondatetime;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPhonno() {
		return phonno;
	}

	public void setPhonno(String phonno) {
		this.phonno = phonno;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getIssudetails() {
		return issudetails;
	}

	public void setIssudetails(String issudetails) {
		this.issudetails = issudetails;
	}

	public String getResolutiondetails() {
		return resolutiondetails;
	}

	public void setResolutiondetails(String resolutiondetails) {
		this.resolutiondetails = resolutiondetails;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public LocalDateTime getCreatedatetime() {
		return createdatetime;
	}

	public void setCreatedatetime(LocalDateTime createdatetime) {
		this.createdatetime = createdatetime;
	}

	public LocalDateTime getResolutiondatetime() {
		return resolutiondatetime;
	}

	public void setResolutiondatetime(LocalDateTime resolutiondatetime) {
		this.resolutiondatetime = resolutiondatetime;
	}


}
