﻿namespace ProductApp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> products = new List<Product>();
            string filePath = "products.txt";

            while (true)
            {
                Console.WriteLine("Choose an option:");
                Console.WriteLine("1. Add Product");
                Console.WriteLine("2. Save Products to File");
                Console.WriteLine("3. Read Products from File");
                Console.WriteLine("4. Exit");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddProduct(products);
                        break;
                    case "2":
                        SaveProductsToFile(products, filePath);
                        break;
                    case "3":
                        ReadProductsFromFile(filePath);
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void AddProduct(List<Product> products)
        {
            Console.Write("Enter Product Code: ");
            string code = Console.ReadLine();

            Console.Write("Enter Product Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Product Price: ");
            if (decimal.TryParse(Console.ReadLine(), out decimal price))
            {
                products.Add(new Product { Code = code, Name = name, Price = price });
                Console.WriteLine("Product added successfully!\n");
            }
            else
            {
                Console.WriteLine("Invalid price. Please try again.\n");
            }
        }

        static void SaveProductsToFile(List<Product> products, string filePath)
        {
            try
            {
               
                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose(); 
                }

              
                using (StreamWriter writer = new StreamWriter(filePath, false)) 
                {
                    foreach (var product in products)
                    {
                        writer.WriteLine($"{product.Code},{product.Name},{product.Price}");
                    }
                }

                Console.WriteLine("Products saved to file successfully!\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving to file: {ex.Message}\n");
            }
        }

        static void ReadProductsFromFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    string[] lines = File.ReadAllLines(filePath);
                    Console.WriteLine("\nProducts in File:");
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split(',');
                        Console.WriteLine($"Code: {parts[0]}, Name: {parts[1]}, Price: {parts[2]}");
                    }
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("File does not exist.\n");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file: {ex.Message}\n");
            }
        }
    }

    class Product
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
