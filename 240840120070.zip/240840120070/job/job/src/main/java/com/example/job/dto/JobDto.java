package com.example.job.dto;

import java.time.LocalDate;

public class JobDto {
	
	
	private int jobid;
	

	private  String title;
	
	
	private String companyname;
 
	
	private String location;
	

	private String description;
	
	
	private int requirements;
	
	
	private int salary;
	
	
	private LocalDate postingdate;
	public int getJobid() {
		return jobid;
	}

	public void setJobid(int jobid) {
		this.jobid = jobid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getRequirements() {
		return requirements;
	}

	public void setRequirements(int requirements) {
		this.requirements = requirements;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public LocalDate getPostingdate() {
		return postingdate;
	}

	public void setPostingdate(LocalDate postingdate) {
		this.postingdate = postingdate;
	}
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	



