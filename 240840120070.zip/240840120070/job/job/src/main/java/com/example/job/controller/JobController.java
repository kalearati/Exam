package com.example.job.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.job.dto.JobDto;
import com.example.job.entity.Job;
import com.example.job.service.JobService;



@RestController
@RequestMapping("/jobPostings")

public class JobController {

	
	  @Autowired
	    JobService jobService;

	    @PostMapping
	    public ResponseEntity<String> createTicket(@RequestBody JobDto jobDto) {
	        boolean isCreated = jobService.addJob(jobDto);
	        if (isCreated) {
	            return ResponseEntity.status(HttpStatus.CREATED).body("Job Posting successfully.");
	        } else {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to create the Job.");
	        }
	    }
	    

		
	    @PutMapping("/updateJob/{jobid}")
	    public ResponseEntity<String> updateJob(@RequestBody JobDto jobDto,@PathVariable("jobid") int jobid) {
	        boolean isUpdated = jobService.updateJob(jobDto);
	        if (isUpdated) {
	            return ResponseEntity.ok("Job updated successfully.");
	        } else {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to update Job.");
	        }
	    }
	    
	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> deleteJob(@PathVariable("id") String id) {
	        boolean isDeleted = jobService.deleteJobById(id);
	        if (isDeleted) {
	            return ResponseEntity.ok("Job deleted successfully.");
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Job not found.");
	        }
	    }
	   
	    
    @GetMapping
	    public ResponseEntity<List<JobDto>> getJobs() {
	        List<JobDto> jobs = jobService.getAllJobs();
	        if (jobs != null && !jobs.isEmpty()) {
	            return ResponseEntity.ok(jobs);
	        } else {
          return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	        }
	        
	        
    }
	    

		
}
