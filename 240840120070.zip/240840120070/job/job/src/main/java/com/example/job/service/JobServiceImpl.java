package com.example.job.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.job.dto.JobDto;
import com.example.job.entity.Job;
import com.example.job.repository.JobRepository;




@Service
public class JobServiceImpl implements JobService {

	@Autowired
	JobRepository jobRepository;

	@Override
	public boolean addJob(JobDto jobDto) {
		
		Job job=new Job();
		BeanUtils.copyProperties(jobDto, job);
		jobRepository.save(job);
		return true;
		
	}
	
	@Override
	public boolean updateJob(JobDto jobDto) {
		Job job=new Job();
		
		BeanUtils.copyProperties(jobDto, job);
		jobRepository.save(job);
		return true;
	}

	@Override
	public List<JobDto> getAllJobs() {
		List<Job> jobs = jobRepository.findAll();
		List<JobDto> jobssDto = new ArrayList<JobDto>();
		for (Job ticket : jobs) {
			JobDto jobDto = new JobDto();
		BeanUtils.copyProperties(ticket, jobDto);
		jobssDto.add(jobDto);
		}
		return jobssDto;
	}

	  @Override
	    public boolean deleteJobById(String id) {
	        if (jobRepository.existsById(id)) {
	            jobRepository.deleteById(id);
	            return true;
	        }
	        return false;
	    }

	

}
