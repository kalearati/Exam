package com.example.job.service;

import java.util.List;

import com.example.job.dto.JobDto;

public interface JobService {
	
	boolean addJob(JobDto jobDto);
	boolean updateJob(JobDto jobDto);
	List<JobDto> getAllJobs();
	 boolean deleteJobById(String id); 


}
